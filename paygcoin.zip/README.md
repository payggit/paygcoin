Paygcoin 
================================

What is Paygcoin?

Paygcoin is my new coin. 

Paygcoin properties:

-Initial reward of 0 coins

-Block interval of 2 minutes

-Maximum supply of ... coins


